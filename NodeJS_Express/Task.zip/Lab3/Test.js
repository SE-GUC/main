const express = require('express')
const bodyParser= require('body-parser')
const app = express()

app.use(bodyParser.urlencoded({extended: true}))


//Route handler
app.get('/', function(req, res){
  res.sendFile(__dirname + '/demoFile.html')
   console.log('Middle');

});


app.post('/Req', (req, res) => {
  console.log('Get the entered data!');
  console.log(req.body);
  console.log("Fname: "+req.body.firstname);
})
app.listen(3000);